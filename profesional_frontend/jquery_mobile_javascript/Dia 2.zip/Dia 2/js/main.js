require(['app'], function(App) {
	App.iniciar();
});